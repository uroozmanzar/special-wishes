Add your photos to this folder.

Default filenames used in content.js:
- cover.jpg
- photo-01.jpg through photo-06.jpg
- video-poster-01.jpg and video-poster-02.jpg (optional video thumbnails)

You can choose other filenames, but update the matching paths in ../content.js.
