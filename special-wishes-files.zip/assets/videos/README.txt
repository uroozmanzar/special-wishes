Add your MP4 video clips to this folder.

Default filenames used in content.js:
- clip-01.mp4
- clip-02.mp4

You can choose other filenames, but update the matching paths in ../content.js.
